<?php

define('DVWA_WEB_PAGE_TO_ROOT', '');
require_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaPage.inc.php';
require_once DVWA_WEB_PAGE_TO_ROOT . 'vendor/autoload.php';  // Load Composer dependencies

use Firebase\JWT\JWT;

dvwaPageStartup(array());
dvwaDatabaseConnect();

if (isset($_POST['Login'])) {
    checkToken($_REQUEST['user_token'], $_SESSION['session_token'], 'login.php');

    $user = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    if (!preg_match('/^[a-zA-Z0-9_]{1,20}$/', $user)) {
        dvwaMessagePush('Invalid username');
        dvwaRedirect('login.php');
        exit;
    }

    $stmt = $GLOBALS["___mysqli_ston"]->prepare("SELECT password, user_id FROM `users` WHERE user = ?");
    $stmt->bind_param('s', $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($_POST['password'], $row['password'])) {
            dvwaMessagePush("You have logged in as '{$user}'");

            $key = "your_secret_key";  // This should be stored securely and not hardcoded
            $issuedAt = time();
            $expirationTime = $issuedAt + 3600;  // Token valid for 1 hour
            $payload = [
                'userid' => $row['user_id'],
                'iat' => $issuedAt,
                'exp' => $expirationTime
            ];

            $jwt = JWT::encode($payload, $key);
            setcookie('auth_token', $jwt, $expirationTime, '/');

            dvwaRedirect(DVWA_WEB_PAGE_TO_ROOT . 'index.php');
        } else {
            dvwaMessagePush('Login failed');
            dvwaRedirect('login.php');
        }
    } else {
        dvwaMessagePush('Login failed');
        dvwaRedirect('login.php');
    }
}

generateSessionToken();
$messagesHtml = messagesPopAllToHtml();

Header('Cache-Control: no-cache, must-revalidate');
Header('Content-Type: text/html;charset=utf-8');
Header('Expires: Tue, 23 Jun 2009 12:00:00 GMT');

include DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaHtmlEcho.inc.php';
